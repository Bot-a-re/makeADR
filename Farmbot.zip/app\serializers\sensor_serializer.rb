class SensorSerializer < ApplicationSerializer
  attributes :pin, :label, :mode
end
