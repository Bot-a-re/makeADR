module FarmEvents
  Destroy = CreateDestroyer.run!(resource: FarmEvent)
end
