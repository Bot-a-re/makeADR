module Telemetries
  Destroy = CreateDestroyer.run!(resource: Telemetry)
end
