module FarmwareInstallations
  Destroy = CreateDestroyer.run!(resource: FarmwareInstallation)
end
