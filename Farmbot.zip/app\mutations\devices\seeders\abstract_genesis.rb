module Devices
  module Seeders
    class AbstractGenesis < AbstractSeeder
      def peripherals_vacuum
        add_peripheral(9, ToolNames::VACUUM)
      end

      def peripherals_water
        add_peripheral(8, ToolNames::WATER)
      end

      def sensors_soil_sensor
        add_sensor(59, ToolNames::SOIL_SENSOR, ANALOG)
      end

      def sensors_tool_verification
        add_sensor(63, ToolNames::TOOL_VERIFICATION, DIGITAL)
      end

      def settings_device_name
        device.update!(name: Names::GENESIS)
      end

      def settings_change_firmware_config_defaults
        device.firmware_config.update!(movement_motor_current_x: 1646)
      end

      def tool_slots_slot_1
        add_tool_slot(name: ToolNames::SEEDER,
                      x: TOOL_X,
                      y: TOOL_Y + 1 * TOOL_SPACING,
                      z: TOOL_Z,
                      tool: tools_seeder)
      end

      def tool_slots_slot_2
        add_tool_slot(name: ToolNames::SEED_BIN,
                      x: TOOL_X,
                      y: TOOL_Y + 2 * TOOL_SPACING,
                      z: TOOL_Z,
                      tool: tools_seed_bin)
      end

      def tool_slots_slot_3
        add_tool_slot(name: ToolNames::SEED_TRAY,
                      x: TOOL_X,
                      y: TOOL_Y + 3 * TOOL_SPACING,
                      z: TOOL_Z,
                      tool: tools_seed_tray)
      end

      def tool_slots_slot_4
        add_tool_slot(name: ToolNames::WATERING_NOZZLE,
                      x: TOOL_X,
                      y: TOOL_Y + 5 * TOOL_SPACING,
                      z: TOOL_Z,
                      tool: tools_watering_nozzle)
      end

      def tool_slots_slot_5
        add_tool_slot(name: ToolNames::SOIL_SENSOR,
                      x: TOOL_X,
                      y: TOOL_Y + 6 * TOOL_SPACING,
                      z: TOOL_Z,
                      tool: tools_soil_sensor)
      end

      def tool_slots_slot_6
        add_tool_slot(name: ToolNames::WEEDER,
                      x: TOOL_X,
                      y: TOOL_Y + 7 * TOOL_SPACING,
                      z: TOOL_Z,
                      tool: tools_weeder)
      end

      def tool_slots_slot_7; end
      def tool_slots_slot_8; end
      def tool_slots_slot_9; end

      def tools_seed_bin
        @tools_seed_bin ||=
          add_tool(ToolNames::SEED_BIN)
      end

      def tools_seed_tray
        @tools_seed_tray ||=
          add_tool(ToolNames::SEED_TRAY)
      end

      def tools_seed_trough_1; end
      def tools_seed_trough_2; end

      def tools_seeder
        @tools_seeder ||=
          add_tool(ToolNames::SEEDER)
      end

      def tools_soil_sensor
        @tools_soil_sensor ||=
          add_tool(ToolNames::SOIL_SENSOR)
      end

      def tools_weeder
        @tools_weeder ||=
          add_tool(ToolNames::WEEDER)
      end

      def tools_rotary; end

      def sequences_mount_tool
        success = install_sequence_version_by_name(PublicSequenceNames::MOUNT_TOOL)
        if !success
          s = SequenceSeeds::MOUNT_TOOL.deep_dup
          Sequences::Create.run!(s, device: device)
        end
      end

      def sequences_dismount_tool
        success = install_sequence_version_by_name(PublicSequenceNames::DISMOUNT_TOOL)
        if !success
          s = SequenceSeeds::DISMOUNT_TOOL.deep_dup
          Sequences::Create.run!(s, device: device)
        end
      end

      def sequences_pick_from_seed_tray
        success = install_sequence_version_by_name(PublicSequenceNames::PICK_FROM_SEED_TRAY)
        if !success
          s = SequenceSeeds::PICK_FROM_SEED_TRAY.deep_dup
          Sequences::Create.run!(s, device: device)
        end
      end

      def sequences_pick_from_seed_trough
        success = install_sequence_version_by_name(PublicSequenceNames::PICK_FROM_SEED_TROUGH)
        if !success
          s = SequenceSeeds::PICK_FROM_SEED_TROUGH.deep_dup
          Sequences::Create.run!(s, device: device)
        end
      end

      def sequences_pick_from_seed_bin
        success = install_sequence_version_by_name(PublicSequenceNames::PICK_FROM_SEED_BIN)
        if !success
          s = SequenceSeeds::PICK_FROM_SEED_BIN.deep_dup
          Sequences::Create.run!(s, device: device)
        end
      end

      def sequences_pick_up_seed; end

      def sequences_plant_seed
        s = SequenceSeeds::PLANT_SEED_GENESIS.deep_dup

        s.dig(:body, 2, :args, :pin_number, :args)[:pin_id] = vacuum_id
        Sequences::Create.run!(s, device: device)
      end

      def sequences_find_home
        s = SequenceSeeds::FIND_HOME_GENESIS.deep_dup
        Sequences::Create.run!(s, device: device)
      end

      def settings_gantry_height
        device.fbos_config.update!(gantry_height: 120)
      end

      def settings_default_map_size_x
        device.web_app_config.update!(map_size_x: 2_900)
      end

      def settings_default_map_size_y
        device.web_app_config.update!(map_size_y: 1_230)
      end

      def pin_bindings_button_1
        add_pin_binding 16, "Emergency Lock", :emergency_lock
      end

      def pin_bindings_button_2
        add_pin_binding 22, "Unlock", :emergency_unlock
      end
    end
  end
end
