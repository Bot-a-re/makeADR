class PointSerializer
end
