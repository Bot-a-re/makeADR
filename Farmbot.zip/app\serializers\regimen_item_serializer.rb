class RegimenItemSerializer < ApplicationSerializer
  attributes :regimen_id, :sequence_id, :time_offset
end
