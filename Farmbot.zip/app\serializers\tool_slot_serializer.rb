class ToolSlotSerializer < BasePointSerializer
  attributes :tool_id, :pullout_direction, :gantry_mounted
end
