class GlobalBulletinSerializer < ApplicationSerializer
  attributes :href, :href_label, :slug, :title, :type, :content
end
