module SavedGardens
  Destroy = CreateDestroyer.run!(resource: SavedGarden)
end
