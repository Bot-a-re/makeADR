class MigrateAwayFromMetaColumn < ActiveRecord::Migration[5.1]

  def up
    # We dont want this one, actually.
  end

  def down
  end
end
