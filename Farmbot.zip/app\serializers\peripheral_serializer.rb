class PeripheralSerializer < ApplicationSerializer
  attributes :pin, :label, :mode
end
