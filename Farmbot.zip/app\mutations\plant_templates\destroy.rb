module PlantTemplates
  Destroy = CreateDestroyer.run!(resource: PlantTemplate)
end
