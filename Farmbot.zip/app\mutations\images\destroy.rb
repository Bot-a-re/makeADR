module Images
  Destroy = CreateDestroyer.run!(resource: Image)
end
