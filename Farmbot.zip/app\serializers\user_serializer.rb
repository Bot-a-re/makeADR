class UserSerializer < ApplicationSerializer
  attributes :name, :email, :language
end
