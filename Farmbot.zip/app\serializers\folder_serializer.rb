class FolderSerializer < ApplicationSerializer
  attributes :id, :parent_id, :color, :name
end
